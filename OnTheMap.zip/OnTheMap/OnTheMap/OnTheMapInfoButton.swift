//
//  OnTheMapInfoButton.swift
//  OnTheMap
//
//  Created by Carlos Lozano on 9/10/17.
//  Copyright © 2017 Carlos Lozano. All rights reserved.
//

import UIKit

class OTMInfoButton: UIButton {
    
    var url :String?
    
}
